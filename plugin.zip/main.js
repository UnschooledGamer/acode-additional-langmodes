"use strict";(()=>{var d={$schema:"https://acode.app/schema/plugin/v0.1.0.json",id:"acode.additional.langmodes",name:"Additional Language Modes",main:"main.js",version:"1.0.0",repository:"",icon:"icon.png",minVersionCode:290,license:"MIT",keywords:["codemirror","language","syntax","autohotkey"],price:0,permissions:[],author:{name:"Acode-Foundation",email:"",github:"Acode-Foundation"}};var X=acode.require("@codemirror/autocomplete"),{completeFromList:g}=X;var x=acode.require("@codemirror/language"),{LanguageSupport:O,LRLanguage:f,foldInside:o,foldNodeProp:h,indentNodeProp:y,delimitedIndent:r}=x;var K=acode.require("@lezer/highlight"),{styleTags:_,tags:e}=K;var R=acode.require("@lezer/lr"),{LRParser:Q}=R;function s(i){return new Set(i.trim().toLowerCase().split(/\s+/))}var u=s(`
	and as break case catch class continue else extends false finally for
	global if in is local loop new not or return static super switch this
	throw true try until while
`),l=s(`
	autotrim blockinput click clipwait control controlclick controlfocus
	controlget controlgetfocus controlgetpos controlgettext controlmove
	controlsend controlsendraw controlsettext coordmode critical
	detecthiddentext detecthiddenwindows drive driveget drivespacefree edit
	envadd envdiv envget envmult envset envsub envupdate exit exitapp
	fileappend filecopy filecopydir filecreatedir filecreateshortcut filedelete
	fileencoding filegetattrib filegetshortcut filegetsize filegettime
	filegetversion fileinstall filemove filemovedir fileread filereadline
	filerecycle filerecycleempty fileremovedir fileselectfile fileselectfolder
	filesetattrib filesettime formattime getkeystate gosub goto groupactivate
	groupadd groupclose groupdeactivate gui guicontrol guicontrolget hotkey
	ifequal ifexist ifgreater ifgreaterorequal ifinstring ifless
	iflessorequal ifmsgbox ifnotequal ifnotexist ifnotinstring ifwinactive
	ifwinexist ifwinnotactive ifwinnotexist imagesearch inidelete iniread
	iniwrite input inputbox keyhistory keywait listhotkeys listlines listvars
	menu mouseclick mouseclickdrag mousegetpos mousemove msgbox onexit
	outputdebug pause pixelgetcolor pixelsearch postmessage process progress
	random regdelete regread regwrite reload run runas runwait send sendevent
	sendinput sendlevel sendmessage sendmode sendplay sendraw setbatchlines
	setcapslockstate setcontroldelay setdefaultmousespeed setenv setformat
	setkeydelay setmousedelay setnumlockstate setregview setscrolllockstate
	setstorecapslockmode settimer settitlematchmode setwindelay setworkingdir
	shutdown sleep sort soundbeep soundget soundgetwavevolume soundplay soundset
	soundsetwavevolume splashimage splashtextoff splashtexton splitpath
	statusbargettext statusbarwait stringcasesense stringgetpos stringleft
	stringlen stringlower stringmid stringreplace stringright stringsplit
	stringtrimleft stringtrimright stringupper suspend sysget thread tooltip
	transform traytip urldownloadtofile winactivate winactivatebottom winclose
	winget wingetactivestats wingetactivetitle wingetclass wingetpos wingettext
	wingettitle winhide winkill winmaximize winmenuselectitem winminimize
	winminimizeall winminimizeallundo winmove winrestore winset winsettitle
	winshow winwait winwaitactive winwaitclose winwaitnotactive
`),b=s(`
	abs acos array asin atan buffer callbackcreate callbackfree caretgetpos
	ceil chr classnn clipboardall clipwait comcall comobjactive comobjarray
	comobjclass comobjconnect comobjflags comobjfromptr comobjget comobjquery
	comobjtype comobjvalue cos dateadd datediff dircopy dircreate direxist
	dirmove dirselect dirdelete download dllcall driveeject drivegetcapacity
	drivegetfilesystem drivegetlabel drivegetlist drivegetserial
	drivegetspacefree drivegetstatus drivegettype drivesetlabel envget envset
	exp fileappend filecopy filecreateShortcut filedelete fileencoding fileexist
	filegetattrib filegetshortcut filegetsize filegettime filegetversion
	fileinstall filemove fileopen fileread filerecycle filerecycleempty
	fileselect filesetattrib filesettime float floor format formattime func
	getkeyname getkeystate getkeysc getkeyvk hasbase hotif hotkey imageSearch
	iniDelete iniRead iniWrite inputBox instr integer islabel isobject
	isnumber isset istype keyhistory keywait listlines listvars ln loadpicture
	log ltrim map max menu min mod monitorget monitorgetcount monitorgetname
	monitorgetprimary monitorgetworkarea mouseclick mouseclickdrag mousedown
	mousegetpos mousemove mouseup mousewheel msgbox numget numput number
	objaddref objgetbase objhasownprop objownpropcount objrelease
	onclipboardchange onerror onexit onmessage ord outputdebug pause
	pixelgetcolor pixelsearch processclose processexist processgetname
	processgetparent processsetpriority processwait processwaitclose
	random randomseed regcreatekey regdelete regdeletekey regenumkey
	regenumval regread regwrite reload round run runas runwait send sendevent
	sendinput sendmessage sendmode sendplay setcapslockstate setcontroldelay
	setdefaultmousespeed setkeydelay setmousedelay setnumlockstate
	setregview setscrolllockstate settimer settitlematchmode setwindelay
	setworkingdir shutdown sin sleep sort soundbeep soundgetinterface
	soundgetmute soundgetname soundgetvolume soundplay soundsetmute
	soundsetvolume splitpath sqrt statusbargettext statusbarwait strcompare
	strget string strlen strlower strptr strput strreplace strsplit strtitle
	strupper substr sysget thread tooltip trayseticon traysettip trim type
	varsetstrcapacity winactivate winactivatebottom winactive winclose winexist
	wingetclass wingetclientpos wingetcontrols wingetcontrolsHwnd wingetcount
	wingetid wingetidlast wingetlist wingetminmax wingetpid wingetpos
	wingetprocessname wingetprocessexepath wingetstyle wingettext wingettitle
	winhide winkill winmaximize winminimize winminimizeall winmove winredraw
	winrestore winsetalwaysontop winsetenabled winsetregion winsetstyle
	winsettitle winsettranscolor winsettransparent winshow winwait
	winwaitactive winwaitclose winwaitnotactive
`),m=s(`
	a_ahkpath a_ahkversion a_appdata a_appdatacommon a_args a_caretx a_carety
	a_computername a_cursor a_dd a_ddd a_dddd a_desktop a_desktopcommon
	a_endchar a_eventinfo a_exitreason a_gui a_guicontrol a_guievent a_guix
	a_guiy a_hour a_iconfile a_iconhidden a_iconnumber a_icontip a_index
	a_ipaddress1 a_ipaddress2 a_ipaddress3 a_ipaddress4 a_is64bitos a_isadmin
	a_iscompiled a_iscritical a_ispaused a_issuspended a_isunicode a_language
	a_lasterror a_linefile a_linenumber a_loopfield a_loopfileattrib
	a_loopfiledir a_loopfileext a_loopfilefullpath a_loopfilelongpath
	a_loopfilename a_loopfileshortname a_loopfileshortpath a_loopfilesize
	a_loopfilesizekb a_loopfilesizemb a_loopfiletimeaccessed
	a_loopfiletimecreated a_loopfiletimemodified a_loopreadline a_mday a_min
	a_mm a_mmm a_mmmm a_mon a_msec a_mydocuments a_now a_nowutc a_ostype
	a_osversion a_priorhotkey a_priorkey a_programfiles a_programs
	a_programscommon a_ptrsize a_screendpi a_screenheight a_screenwidth
	a_scriptdir a_scriptfullpath a_scripthwnd a_scriptname a_sec a_space
	a_startmenu a_startmenucommon a_startup a_startupcommon a_tab a_temp
	a_thisfunc a_thishotkey a_thislabel a_thismenu a_thismenuitem
	a_thismenuitempos a_tickcount a_timeidle a_timeidlephysical
	a_timesincepriorhotkey a_timesincethishotkey a_username a_wday a_windir
	a_workingdir a_yday a_year a_yweek a_yyyy clipboard clipboardall comspec
	errorlevel programfiles
`);var de=new Map([["and",74],["break",67],["byref",64],["case",59],["catch",56],["class",46],["continue",68],["default",60],["else",49],["exit",69],["exitapp",70],["extends",47],["false",73],["finally",57],["for",50],["global",61],["if",48],["in",51],["local",62],["loop",53],["new",71],["not",76],["or",75],["return",65],["static",63],["switch",58],["throw",66],["true",72],["try",55],["until",54],["while",52]]);function p(i){let t=i.toLowerCase();return de.get(t)??(b.has(t)?1:l.has(t)?2:-1)}var v=Q.deserialize({version:14,states:"&rQVQPOOO$[QPO'#CeOOQO'#Ch'#ChOOQO'#Cj'#CjO$aQPO'#CoO$hQPO'#ClO$mQPO'#C`O(RQPO'#CwO(YQPO'#CzOOQO'#C{'#C{OOQO'#C|'#C|OOQO'#C}'#C}OOQO'#DO'#DOOOQO'#DP'#DPOOQO'#DQ'#DQOOQO'#DS'#DSOOQO'#DU'#DUOOQO'#DW'#DWOOQO'#C`'#C`OOQO'#DY'#DYQVQPOOOOQO,59P,59POOQO,59Z,59ZO(aQPO,59ZO(hQPO,59WO(pQPO'#CsO(wQPO,59`OOQO,59b,59bOOQO,59c,59cO,YQPO,59cOOQO,59f,59fO,aQPO,59fOOQO-E7W-E7WOOQO1G.u1G.uOOQO1G.r1G.rO,hQPO1G.rOOQO,59_,59_O,mQPO,59_OOQO1G.v1G.vOOQO1G.}1G.}OOQO1G/Q1G/QO,tQPO7+$^OOQO1G.y1G.yOOQO<<Gx<<Gx",stateData:"-W~O!pOS~OP[OQ]OTbOUbOVbOWbOYPOZUO]QO_RObSOfVOmWOu^Ow_Oy`O{aO!OTO!QYO!RYO!SYO!TYO!UYO!VYO!WYO!XYO!YYO!ZYO![YO!]YO!^YO!_ZO!`ZO!aZO!bZO!cYO!dYO!eYO!fYO!gYO!hYO!iYO!jXO!kXO!lYO!mYO!nYO~OZeO~OafO~PVOZhO~OfiOikOPSXQSXTSXUSXVSXWSXYSXZSX]SX_SXbSXmSXuSXwSXySX{SX}SX!OSX!QSX!RSX!SSX!TSX!USX!VSX!WSX!XSX!YSX!ZSX![SX!]SX!^SX!_SX!`SX!aSX!bSX!cSX!dSX!eSX!fSX!gSX!hSX!iSX!jSX!kSX!lSX!mSX!nSXaSXeSXlSX~OelO~PVOlnO~PVOaqO~PVObSO!PsO~OetO~PVObSOPhaQhaThaUhaVhaWhaYhaZha]ha_hafhamhauhawhayha{ha}ha!Oha!Qha!Rha!Sha!Tha!Uha!Vha!Wha!Xha!Yha!Zha![ha!]ha!^ha!_ha!`ha!aha!bha!cha!dha!eha!fha!gha!hha!iha!jha!kha!lha!mha!nhaahaehalha~OewO~PVOlxO~PVOZyO~OezO~PVObSO~OTUV]_WuwZy{W~",goto:"#h}PPPP!OPPPP![PP![P![P![PP!h![PP!}![P![![PP![![![![![![![P![P![P![P#QecOSVWdgimouebOSVWdgimoudbOSVWdgimouQrhQvjR{yRjUQdOQgSQmVQoWYpdgmouRui",nodeNames:"\u26A0 BuiltinFunctionName CommandName Script Element LineComment BlockComment String Number Directive # Identifier HotstringDeclaration HotstringHeader HotkeyDeclaration HotkeyHeader ClassDeclaration } { Block FunctionDeclaration ) ( ArgumentList FunctionCall : LabelOrProperty Parenthesized ] [ Bracketed Boolean ControlKeyword DefinitionKeyword BuiltinFunction Command BuiltinVariable BuiltinVariableName PercentVariable PercentIdentifier Operator OperatorToken Punctuation PunctuationToken",maxTerm:78,nodeProps:[["openedBy",17,"{",21,"(",28,"["],["closedBy",18,"}",22,")",29,"]"]],skippedNodes:[0],repeatNodeCount:1,tokenData:"! T~RyXY#rYZ#r]^#rpq#rqr$Trs&zst(ltu)vuv+ovw,wwx/`xy0}yz1Sz{1X{|2f|}3s}!O3x!O!P4T!P!Q5Y!Q!R6s!R![8v![!]C^!]!^E{!^!_Fg!_!`IP!`!aI[!a!b&u!b!c+T!c!dJi!d!})v!}#ONd#P#QNi#Q#R$T#R#S)v#S#T3s#T#UJi#U#o)v#o#pNn#p#qNs#q#r! O#r#s$T~#wS!p~XY#rYZ#r]^#rpq#r~$Yby~XY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q![%b![!]&j!^!_%b!_!`&u!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~%eaXY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q![%b![!]&j!^!_%b!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~&mP![!]&p~&uO_~~&zOy~~'PXV~OY&zZ]&z^r&zrs'ls#S&z#S#T't#T;'S&z;'S;=`(f<%lO&z~'qPV~rs&z~'yXV~OY&zZ]&z^r&zrs'ts#S&z#S#T't#T;'S&z;'S;=`(f<%lO&z~(iP;=`<%l&z~(qaY~XY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q![%b![!]&j!^!_%b!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~){bZ~XY%bpq%bqr%bst)vtu)vvw%bz{%b{|%b!Q![)v![!]&j!^!_%b!`!a%b!b!c+T!c!})v#Q#R%b#R#S)v#T#o)v#r#s%b~+YVZ~st+Ttu+T!Q![+T!b!c+T!c!}+T#R#S+T#T#o+T~+tTy~tu,T!b!c,T!c!},T#R#S,T#T#o,T~,YWw~st,Ttu,Tuv,r!Q![,T!b!c,T!c!},T#R#S,T#T#o,T~,wOw~~,|by~XY%bpq%bqr%bst%btu%bvw.Uz{%b{|%b!Q![%b![!]&j!^!_%b!_!`&u!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~.Zay~XY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q![%b![!]&j!^!_%b!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~/eXV~OY/`Z]/`^w/`wx0Qx#S/`#S#T0V#T;'S/`;'S;=`0w<%lO/`~0VOV~~0[XV~OY/`Z]/`^w/`wx/`x#S/`#S#T0V#T;'S/`;'S;=`0w<%lO/`~0zP;=`<%l/`~1SOf~~1XOe~~1^by~XY%bpq%bqr%bst%btu%bvw%bz{.U{|%b!Q![%b![!]&j!^!_%b!_!`&u!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~2kby~XY%bpq%bqr%bst%btu%bvw%bz{%b{|.U!Q![%b![!]&j!^!_%b!_!`&u!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~3xO{~~3}Qy~}!O&u!_!`&u~4YQy~!Q![4`!_!`&u~4eRW~!Q![4`!g!h4n#X#Y4n~4qR{|4z}!O4z!Q![5Q~4}P!Q![5Q~5VPW~!Q![5Q~5_Ry~z{5h!P!Q6k!_!`&u~5mTU~Oz5hz{5|{;'S5h;'S;=`6e<%lO5h~6PTO!P5h!P!Q6`!Q;'S5h;'S;=`6e<%lO5h~6eOU~~6hP;=`<%l5h~6pPy~!_!`&u~6xnW~XY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!O!P4`!Q![8v![!]&j!^!_%b!`!a%b!c!d%b!d!e>O!e!g%b!g!h:a!h!z%b!z!{@n!{!}%b#Q#R%b#R#S%b#T#U%b#U#V>O#V#X%b#X#Y:a#Y#l%b#l#m@n#m#o%b#r#s%b~8{fW~XY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!O!P4`!Q![8v![!]&j!^!_%b!`!a%b!c!g%b!g!h:a!h!}%b#Q#R%b#R#S%b#T#X%b#X#Y:a#Y#o%b#r#s%b~:dbXY%bpq%bqr%bst%btu%bvw%bz{%b{|;l}!O4z!Q![<t![!]&j!^!_%b!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~;oaXY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q![<t![!]&j!^!_%b!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~<yaW~XY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q![<t![!]&j!^!_%b!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~>RcXY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q!R?^!R!S?^!S![%b![!]&j!^!_%b!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~?ccW~XY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q!R?^!R!S?^!S![%b![!]&j!^!_%b!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~@qcXY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q![A|![!]&j!^!_%b!`!a%b!c!iA|!i!}%b#Q#R%b#R#S%b#T#ZA|#Z#o%b#r#s%b~BRcW~XY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q![A|![!]&j!^!_%b!`!a%b!c!iA|!i!}%b#Q#R%b#R#S%b#T#ZA|#Z#o%b#r#s%b~CcXi~z{DO{|DO}!ODO!Q![DO![!]Dk!_!`&u!a!bDO!c!}DO#T#oDO~DRWz{DO{|DO}!ODO!Q![DO![!]Dk!a!bDO!c!}DO#T#oDO~DnUOYEQZ]EQ^![EQ!];'SEQ;'S;=`Eu<%lOEQ~ETVOYEQZ]EQ^![EQ![!]Ej!];'SEQ;'S;=`Eu<%lOEQ~EmP![!]Ep~EuO]~~ExP;=`<%lEQ~FQTT~OYE{Z]E{^;'SE{;'S;=`Fa<%lOE{~FdP;=`<%lE{~Flby~XY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q![%b![!]&j!^!_Gt!_!`&u!`!a.U!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~GwbXY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q![%b![!]&j!^!_%b!_!`&u!`!a%b!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~IUQy~!_!`&u!`!a&u~Iaby~XY%bpq%bqr%bst%btu%bvw%bz{%b{|%b!Q![%b![!]&j!^!_%b!_!`&u!`!aGt!c!}%b#Q#R%b#R#S%b#T#o%b#r#s%b~JnbZ~XY%bpq%bqr%bst)vtu)vvw%bz{%b{|%b!Q![)v![!]&j!^!_%b!`!a%b!b!c+T!c!})v#Q#R%b#R#SKv#T#o)v#r#s%b~K{bZ~XY%bpq%bqr%bst)vtu)vvw%bz{%b{|%b!Q![MT![!]&j!^!_%b!`!a%b!b!c+T!c!}MT#Q#R%b#R#SMT#T#oMT#r#s%b~M[bu~Z~XY%bpq%bqr%bst)vtu)vvw%bz{%b{|%b!Q![MT![!]&j!^!_%b!`!a%b!b!c+T!c!}MT#Q#R%b#R#SMT#T#oMT#r#s%b~NiOm~~NnOl~~NsOb~~NxQy~!_!`&u#p#q&u~! TOa~",tokenizers:[0],topRules:{Script:[0,3]},specialized:[{term:11,get:(i,t)=>p(i,t)<<1,external:p}],tokenPrec:547});var ue=v.configure({props:[_({"LineComment BlockComment":e.comment,Directive:e.meta,HotstringHeader:e.special(e.string),HotkeyHeader:e.special(e.labelName),"LabelOrProperty/Identifier":e.labelName,"FunctionDeclaration/Identifier":e.function(e.definition(e.variableName)),"FunctionCall/Identifier":e.function(e.variableName),"ClassDeclaration/Identifier":e.definition(e.className),BuiltinVariableName:e.constant(e.variableName),PercentIdentifier:e.special(e.variableName),Identifier:e.variableName,String:e.string,Number:e.number,Boolean:e.bool,"classKw extendsKw newKw":e.keyword,ControlKeyword:e.controlKeyword,DefinitionKeyword:e.definitionKeyword,BuiltinFunctionName:e.standard(e.function(e.variableName)),CommandName:e.standard(e.function(e.variableName)),"andKw orKw notKw":e.logicOperator,OperatorToken:e.operator,"( )":e.paren,"[ ]":e.squareBracket,"{ }":e.brace,": # PunctuationToken":e.punctuation}),y.add({Block:r({closing:"}"}),Bracketed:r({closing:"]"}),ArgumentList:r({closing:")"}),Parenthesized:r({closing:")"})}),h.add({Block:o,Bracketed:o,ArgumentList:o,Parenthesized:o})]}),S=f.define({name:"autohotkey",parser:ue,languageData:{commentTokens:{line:";",block:{open:"/*",close:"*/"}},closeBrackets:{brackets:["(","[","{","'",'"']},indentOnInput:/^\s*}$/,wordChars:"#@$"}}),me=[...u,...l,...b,...m].map(i=>({label:i,type:u.has(i)?"keyword":m.has(i)?"constant":"function"})),pe=S.data.of({autocomplete:g(me)});function we(){return new O(S,[pe])}var k={name:"autohotkey",caption:"AutoHotkey",extensions:["ahk","ah1","ah2","ahk1","ahk2"],load:we};var P=[k];function ge(i){return String(i||"").trim().toLowerCase()}var c=class{constructor(t){this.editorLanguages=t,this.registeredNames=[]}registerAll(t){for(let a of t)this.register(a)}register(t){let a=ge(t?.name);if(!a||typeof t?.load!="function")throw new TypeError("Invalid language mode descriptor.");if(this.editorLanguages.get?.(a))return console.info(`[${a}] Language support is already available.`),!1;let n=[...new Set(t.extensions||[])];return this.editorLanguages.register(a,n,t.caption||a,t.load),this.registeredNames.push(a),!0}unregisterAll(){for(let t of this.registeredNames.reverse())this.editorLanguages.unregister(t);this.registeredNames=[]}};var w=class{constructor(){this.registry=null}async init(){let t=acode.require("editorLanguages");if(!t?.register||!t?.unregister)throw new Error("This Acode version does not expose the CodeMirror language registration API.");this.registry=new c(t),this.registry.registerAll(P)}async destroy(){this.registry?.unregisterAll(),this.registry=null}};if(window.acode){let i=new w;acode.setPluginInit(d.id,async(t,a,n)=>{i.baseUrl=t.endsWith("/")?t:`${t}/`,await i.init(a,n?.cacheFile,n?.cacheFileUrl)}),acode.setPluginUnmount(d.id,()=>i.destroy())}})();
