# Additional Language Modes for Acode

Adds CodeMirror language support for languages that are not bundled with Acode.

## Included modes

- AutoHotkey (`.ahk`, `.ah1`, `.ah2`, `.ahk1`, `.ahk2`)
  - generated Lezer parser for incremental, error-tolerant syntax trees
  - AutoHotkey v1 and v2 syntax highlighting
  - directives, hotkeys, hotstrings, labels, commands, functions, variables,
    strings, continuation sections, and comments
  - syntax-aware indentation, folding, comments, bracket closing, and
    completions

## Adding another language

1. Create `src/languages/<language>/index.js`.
2. Export a descriptor containing `name`, `caption`, `extensions`, and a lazy
   `load()` function that returns a CodeMirror extension or `LanguageSupport`.
3. Add the descriptor to `src/languages/index.js`.

The language can use `StreamLanguage`, `LRLanguage` with a Lezer parser, or an
existing CodeMirror language package. Registration and cleanup are handled by
the shared registry.

## Build

```sh
npm install
npm run check
npm run build
```
